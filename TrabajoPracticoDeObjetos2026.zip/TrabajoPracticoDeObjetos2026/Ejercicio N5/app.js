const Empleados=[];
function agregarEmpleado(){
    const empleado={
        nombre: document.getElementById("nombre").value,
        apellido: document.getElementById("apellido").value,
        dni: document.getElementById("dni").value,  
        direccion: document.getElementById("direccion").value,
        salariohs: Number(document.getElementById("sueldohs").value),
        preciohs: Number(document.getElementById("preciohs").value),
        SalarioMensual: function(){
            return this.salariohs*this.preciohs;
        }
    };
    Empleados.push(empleado);
    console.log(Empleados);
    mostrarEmpleado();
}
function mostrarEmpleado() {
    let contenido="<h2>Empleados cargados</h2>";
    Empleados.forEach(function(empleado){
        contenido+=`
        <div class="resultado-card shadow">
        <h3>${empleado.nombre} ${empleado.apellido}</h3>
        <p><strong>DNI:</strong> ${empleado.dni}</p>
        <p><strong>Dirección:</strong> ${empleado.direccion}</p>
        <p><strong>Precio por hora:</strong> $${empleado.preciohs}</p>
        <p><strong>Horas trabajadas:</strong> ${empleado.salariohs} horas</p>
        <p><strong>Salario mensual:</strong> $${empleado.SalarioMensual()}</p>
        </div>
        `;
    });
    document.getElementById("resultado").innerHTML=contenido;
}