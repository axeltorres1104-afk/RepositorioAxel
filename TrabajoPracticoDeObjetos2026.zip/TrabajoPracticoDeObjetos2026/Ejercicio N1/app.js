function mostrarAuto(){
    //creamos el obj de auto de los valores que ingrese el usuario
   
    const auto ={
     marca: document.getElementById("marca").value,
     modelo: document.getElementById("modelo").value,
     año: document.getElementById("año").value,
     color: document.getElementById("color").value,
     estado: document.getElementById("estado").value,
     precio: document.getElementById("precio").value
    }
    //Mostramos la info en el documento usando innerHTML
    document.getElementById("resultado").innerHTML = `
        <div class="resultado-card shadow">
            <h3>Datos del Auto</h3>
            <p><strong>Marca:</strong> ${auto.marca}</p>
            <p><strong>Modelo:</strong> ${auto.modelo}</p>
            <p><strong>Año:</strong> ${auto.año}</p>
            <p><strong>Color:</strong> ${auto.color}</p>
            <p><strong>Estado:</strong> ${auto.estado}</p>
            <p><strong>Precio:</strong> $${auto.precio}</p>
        </div>
    `;
}