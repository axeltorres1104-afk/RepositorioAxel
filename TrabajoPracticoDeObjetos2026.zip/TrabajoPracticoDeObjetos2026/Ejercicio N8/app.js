// Array de objetos con usuarios precargados
const Usuarios = [
  {
    nombreUsuario: "admin",
    contraseña: "1234",
    fechaCreacion: "2026-05-03"
  },
  {
    nombreUsuario: "axel",
    contraseña: "programacion",
    fechaCreacion: "2026-05-03"
  }
];

// Array de objetos con contactos precargados
const Contactos = [
  {
    nomyApe: "Juan Pérez",
    telefono: "3814567890",
    direccion: "San Martín 450",
    email: "juanperez@gmail.com"
  },
  {
    nomyApe: "María Gómez",
    telefono: "3815551234",
    direccion: "Belgrano 320",
    email: "mariagomez@gmail.com"
  },
  {
    nomyApe: "Carlos Díaz",
    telefono: "3816677889",
    direccion: "Av. Mate de Luna 1200",
    email: "carlosdiaz@gmail.com"
  },
  {
    nomyApe: "Lucía Fernández",
    telefono: "3819988776",
    direccion: "25 de Mayo 800",
    email: "luciafernandez@gmail.com"
  }
];

// Función para validar el login
function validarLogin() {
  const usuarioIngresado = document.getElementById("usuario").value;
  const contraseñaIngresada = document.getElementById("contraseña").value;

  const usuarioEncontrado = Usuarios.find(function(usuario) {
    return usuario.nombreUsuario === usuarioIngresado &&
           usuario.contraseña === contraseñaIngresada;
  });

  if (usuarioEncontrado) {
    window.location.href = "agenda.html";
  } else {
    document.getElementById("mensaje").innerHTML = "Usuario o contraseña incorrectos";
  }
}

// Función para mostrar los contactos en la tabla
function mostrarContactos() {
  let filas = "";

  Contactos.forEach(function(contacto) {
    filas += `
      <tr>
        <td>${contacto.nomyApe}</td>
        <td>${contacto.telefono}</td>
        <td>${contacto.direccion}</td>
        <td>${contacto.email}</td>
      </tr>
    `;
  });

  document.getElementById("tablaContactos").innerHTML = filas;
}

// Verificamos si existe la tabla antes de ejecutar mostrarContactos
if (document.getElementById("tablaContactos")) {
  mostrarContactos();
}