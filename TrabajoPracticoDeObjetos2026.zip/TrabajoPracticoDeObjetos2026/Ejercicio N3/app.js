function mostrarProducto() {
     const producto = {
         nombre: document.getElementById("nombre").value,
         precio: Number(document.getElementById("precio").value),
         descripcion: document.getElementById("descripcion").value,
         marca: document.getElementById("marca").value,
         descuento: Number(document.getElementById("descuento").value),

     calcularDescuento: function() {
        const descuentoAplicado = this.precio * (this.descuento / 100);
        const precioConDescuento = this.precio - descuentoAplicado;
        return precioConDescuento;
        }
    };

document.getElementById("resultado").innerHTML = `
    <div class="resultado-card shadow">
        <h3>Datos del Producto</h3>
        <p><strong>Nombre:</strong> ${producto.nombre}</p>
        <p><strong>Precio:</strong> $${producto.precio}</p>
        <p><strong>Descripción:</strong> ${producto.descripcion}</p>
        <p><strong>Marca:</strong> ${producto.marca}</p>
        <p><strong>Descuento:</strong> ${producto.descuento}%</p>
        <p><strong>Precio con Descuento:</strong> $${producto.calcularDescuento()}</p>
    </div>
`;
}