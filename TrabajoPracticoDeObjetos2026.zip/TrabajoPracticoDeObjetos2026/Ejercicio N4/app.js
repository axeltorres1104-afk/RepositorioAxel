function mostrarEmpleado() {
  const Empleado = {
    nombre: document.getElementById("nombre").value,
    apellido: document.getElementById("apellido").value,
    dni: document.getElementById("dni").value,
    direccion: document.getElementById("direccion").value,
    salarioxMes: Number(document.getElementById("salario").value)
  };

  document.getElementById("resultado").innerHTML = `
    <div class="resultado-card shadow">
      <h3>Datos del Empleado</h3>

      <p><strong>Nombre:</strong> ${Empleado.nombre}</p>
      <p><strong>Apellido:</strong> ${Empleado.apellido}</p>
      <p><strong>DNI:</strong> ${Empleado.dni}</p>
      <p><strong>Dirección:</strong> ${Empleado.direccion}</p>
      <p><strong>Salario mensual:</strong> $${Empleado.salarioxMes}</p>
    </div>
  `;
}