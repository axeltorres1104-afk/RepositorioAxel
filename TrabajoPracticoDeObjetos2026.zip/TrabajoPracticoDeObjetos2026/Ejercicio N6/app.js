const LibrosTotales=[];
function agregarLibro(){
    const libro={
        titulo: document.getElementById("titulo").value,
        autor: document.getElementById("autor").value,
        genero: document.getElementById("genero").value,
        año: Number(document.getElementById("año").value)
    };
    LibrosTotales.push(libro);
    console.log(LibrosTotales);
    mostrarLibros();
    }
    function mostrarLibros() {
        let contenido="<h2>Libros cargados</h2>";
        LibrosTotales.forEach(function(libro){
            contenido+=`
            <div class="resultado-card shadow">
            <ul class="list-group">
            <li class="list-group-item"><strong>Título:</strong> ${libro.titulo}</li>
            <li class="list-group-item"><strong>Autor:</strong> ${libro.autor}</li>
            <li class="list-group-item"><strong>Genero:</strong> ${libro.genero}</li>
            <li class="list-group-item"><strong>Año de Publicación:</strong> ${libro.año}</li>
            </ul>
            </div>
            `;
        });
        document.getElementById("resultado").innerHTML=contenido;
    }